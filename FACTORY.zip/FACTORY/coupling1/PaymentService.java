package com.oracle.springtraining.coupling1;

public class PaymentService {
	
	private SavingsAccount savingsAccount;
	private CurrentAccount currentAccount;
	
	public PaymentService(String accNumber,String accType) {
		if(accType.equals("S"))
			savingsAccount = new SavingsAccount(accNumber);
		else if (accType.equals("C"))
			currentAccount = new CurrentAccount(accNumber);
	}
	public void pay(){
	
		System.out.println("Payment using tight coupling ->"+ this.savingsAccount.getDetails());
	}
}
