package com.oracle.springtraining.coupling1.factorysolution;

public class HouseLoanAccount implements Account{

	private String accountNumber;
	private String totalBalance;
	
	
	public HouseLoanAccount(String accountNUmber) {
		this.accountNumber = accountNUmber;
	}
	public String getDetails(){
		System.out.println("HouseLoan Account getDetails() called");
		return accountNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTotalBalance() {
		return totalBalance;
	}
	public void setTotalBalance(String totalBalance) {
		this.totalBalance = totalBalance;
	}
	
}
