package com.oracle.springtraining.coupling1.factorysolution;

public class GoldLoanAccount implements Account{

	private String accountNumber;
	private String totalBalance;
	
	
	public GoldLoanAccount(String accountNUmber) {
		this.accountNumber = accountNUmber;
	}
	public String getDetails(){
		System.out.println("Gold Account getDetails() called");
		return accountNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTotalBalance() {
		return totalBalance;
	}
	public void setTotalBalance(String totalBalance) {
		this.totalBalance = totalBalance;
	}
	
}
