package com.oracle.springtraining.coupling1.interfacesolutions;

public interface Account {
	
		public String getDetails();
}
